previous uses:
https://www.browserbased.org/next-beginning/
https://www.browserbased.org/nfcdab-2022-gardony-hu/

recommended font: san-serif family.